# -*- coding: utf-8 -*-
"""
D:/vah/presupuestos/__init__.py

Paquete principal del sistema de presupuestos VAH.

Este paquete contiene:
- Módulo principal de presupuestos (modulo_presupuestos.py)
- Módulos de cálculo especializados (calculators/)
- Utilidades comunes (common/)
- Sistema de servicio de datos (service.py)
- Módulos de búsqueda y foco (busquedas.py, foco.py)

NUEVO: Módulo core para constantes y utilidades centralizadas.
"""

# Version del paquete
__version__ = "2.0.0"
__author__ = "Equipo de Desarrollo VAH"
__description__ = "Sistema de Presupuestos para Aluminio y Herrería"

# Exportar el módulo principal para importación directa
from .modulo_presupuestos import PresupuestosWindow, main

# Exportar módulos del core
from .core import constants

# Para compatibilidad con importaciones existentes
__all__ = [
    'PresupuestosWindow',
    'main',
    'constants'
]
